# Etapa finala - Proiect POO : POO TV
Nume: Comsa Iuliana Violeta
Grupa: 321 CA
#### Assignment Link: https://ocw.cs.pub.ro/courses/poo-ca-cd/teme/proiect/etapa2
#### Repo Link: hhttps://github.com/Violeta2002/POO-TV---Proiect

## My Classes - README
* fileio - contains the classes that handle the input
    - ActionsInput, ContainsInput, UsersInput, MoviesInput, FiltersInput, SortInput, Input, CredentialsInput
* tvmechanism/
  * Actions - contains the main method that handles all the actions executed by the user like: change page or
  action on a certain page. The most important methods inside this class are: change page that verifies if the
  user can go to a page from the current one and changes the page if possible, the doFeature method that executes
  a specific feature. This page also makes the connection between the input and the output.
  * Credentials - contains the credentials of the user needed to login or register
  * Filters - filters the movies by the given criteria \
    ~ Filters - contains 2 class objects, one for sorting the movies and one for filtering them by actors or genres\
    ~ Sort - contains the sorting methods (by rating or duration) \
    ~ Contains - contains the filtering methods (by actors or genres) \
    - In the Filters class i used the Builder design pattern because i wanted to have a class that can be
     easily extended with new filters and sorting methods and i needed to create a Filters object with only
     one of the 2 classes (Sort or Contains) and not both of them
  * Movies - contains the movie object that contains the movie's details
  * Users - contains the user object that contains the user's details, credentials and the user's history regarding
    the movies he purcased, watched, rated of liked.
  * Notifications - contains the details of a notification populated when a movie is added or deleted from the database
        and at the end of the program where a recommendation is made for the premium user
* pages/
  * Page - it is an abstract class that is the base class for all the pages and contains a method called canVisit()
  that checks if a page can pe visited from a certain page or not
  * CurrentPage - it is a Singleton class that i used to keep track of the current page, current user, current movie list,
  current users list and other variables that i needed to keep track of and that i wanted to use in multiple classes
  * HomeppageNeadentificat - the homepage for the users that are not logged in
  * LoginPage - the login page for the users that are not logged in and it contains a login method that checks if someone
  if already logged in and if not it checks if the credentials are correct and if they are it logs the user in
  * RegisterPage - the register page for the users that are not logged in and it contains a register method that adds a new
    user to the users list
  * SeeDetailsPage - the page that shows the details of a movie that is selected from the movie list if it exists and can also
  execute actions like purchase, rate, like or watch the movie for the user that is logged in
  * UpgradesPage - the page that contains methods like buy tokens that allows the current users to buy tokens that can
  be used when purchasing a movie or to buy a subscription and also contains a method that allows the user to buy
  a premium account if he has enough tokens
  * MoviesPage - the page that contains a method needed to verify what pages can be visited from the movies page
* observer/
    * Observer - it is an interface that contains the update method that is called when a notification is made
    * Subject - it is a class that contains the methods needed to add, remove or notify observers
    * Database - it is a class that extends the Observer class and it is used to update the database when a movie is added
        * or deleted
* command/
  * Command - it is an interface that contains the execute method that is called when a command is executed
  * CommandHistory - it is a singleton class that contains the list of the pages that were visited by the user
  * NextPage - it is a class that extends the Command class and it is used to change the page to the next one
  * PreviousPage - it is a class that extends the Command class and it is used to change the page to the previous one


  * Main - contains the main method that extracts the users list and the movies list from input and also contains the main
  loop that keeps the program running and allows the user to navigate through the pages and execute actions.

  * Design patterns used in my project: Singleton, Builder, Observer and Command \
  \
  Dependecy between classes
![img.png](img.png)

