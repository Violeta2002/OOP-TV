package observer;

import com.fasterxml.jackson.databind.node.ObjectNode;

public abstract class Observer {
    protected Subject subject;

    /**
     *
     * @param node - node in which the state is added
     * @return - a code of success or failure
     */
    public abstract int update(ObjectNode node);
}

