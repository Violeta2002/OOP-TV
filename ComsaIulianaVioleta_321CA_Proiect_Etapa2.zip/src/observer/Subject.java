package observer;

import com.fasterxml.jackson.databind.node.ObjectNode;

import java.util.ArrayList;

public final class Subject {
    private ArrayList<Observer> observers = new ArrayList<>();
    private String state;

    /**
     * @param observer - observer to be added
     */
    public void addObserver(final Observer observer) {
        observers.add(observer);
    }

    /**
     * @param node - node in which the state is added
     * @return - a code of success or failure
     */
    public int notifyObservers(final ObjectNode node) {
        int err = 0;
        for (Observer observer : observers) {
            err = observer.update(node);
        }
        return err;
    }

    /**
     * @param feature - feature to be done
     * @param node - node in which the state is added
     * @return - a code of success or failure
     */
    public int setState(final String feature, final ObjectNode node) {
        this.state = feature;
        return notifyObservers(node);
    }

    /**
     * @return - the state
     */
    public Object getState() {
        return this.state;
    }
}
