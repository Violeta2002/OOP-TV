package tvmechanism;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.util.ArrayList;

import static pages.CurrentPage.getInstance;

public final class Helper {
    /**
     * Method that adds the credentials of the user to a JsonNode
     *
     * @param node        - the node where the output will be written
     * @param credentials - the credentials of the user
     */
    public static void addCredentialsToNode(final ObjectNode node, final Credentials credentials) {
        node.put("name", credentials.getName());
        node.put("password", credentials.getPassword());
        node.put("accountType", credentials.getAccountType());
        node.put("country", credentials.getCountry());
        node.put("balance", credentials.getBalance());
    }

    /**
     * Method that add the user's data to a JsonNode
     *
     * @param node        - the node where the output will be written
     * @param currentUser - the current user
     */
    public static void addUserData(final ObjectNode node, final Users currentUser) {
        ObjectMapper objectMapper = new ObjectMapper();
        node.put("tokensCount", currentUser.getTokensCount());
        node.put("numFreePremiumMovies", currentUser.getNumFreePremiumMovies());

        ArrayNode purchased = objectMapper.createArrayNode();
        if (currentUser.getPurchasedMovies().size() > 0) {
            addFeaturedListToList(purchased, currentUser.getPurchasedMovies(), currentUser);
        }

        ArrayNode watched = objectMapper.createArrayNode();
        if (currentUser.getPurchasedMovies().size() > 0) {
            addFeaturedListToList(watched, currentUser.getWatchedMovies(), currentUser);
        }

        ArrayNode liked = objectMapper.createArrayNode();
        if (currentUser.getWatchedMovies().size() > 0) {
            addFeaturedListToList(liked, currentUser.getLikedMovies(), currentUser);
        }

        ArrayNode rated = objectMapper.createArrayNode();
        if (currentUser.getRatedMovies().size() > 0) {
            addFeaturedListToList(rated, currentUser.getRatedMovies(), currentUser);
        }

        ArrayNode notif = objectMapper.createArrayNode();
        if (getInstance().getNotifcations().get(currentUser) != null) {
            for (Notification notification : getInstance().getNotifcations().get(currentUser)) {
                ObjectNode notifNode = objectMapper.createObjectNode();
                notifNode.put("movieName", notification.getMovieName());
                notifNode.put("message", notification.getMessage());
                notif.add(notifNode);
            }
        }

        node.put("purchasedMovies", purchased);
        node.put("watchedMovies", watched);
        node.put("likedMovies", liked);
        node.put("ratedMovies", rated);
        node.put("notifications", notif);
    }

    /**
     * Method that adds the movies from a list to a JsonNode
     *
     * @param movieDetails - the details of the movie
     * @param movie        - the movie
     */
    public static void addMovieToNode(final ObjectNode movieDetails, final Movies movie) {
        ObjectMapper objectMapper = new ObjectMapper();
        ArrayNode genres = objectMapper.createArrayNode();
        ArrayNode actors = objectMapper.createArrayNode();
        ArrayNode countries = objectMapper.createArrayNode();
        movieDetails.put("name", movie.getName());
        movieDetails.put("year", movie.getYear());
        movieDetails.put("duration", movie.getDuration());
        for (String genre : movie.getGenres()) {
            genres.add(genre);
        }
        movieDetails.put("genres", genres);
        for (String actor : movie.getActors()) {
            actors.add(actor);
        }
        movieDetails.put("actors", actors);
        for (String country : movie.getCountriesBanned()) {
            countries.add(country);
        }
        movieDetails.put("countriesBanned", countries);
        movieDetails.put("numLikes", movie.getNumLikes());
        movieDetails.put("rating", movie.getRating());
        movieDetails.put("numRatings", movie.getNumRatings());
    }

    /**
     * Method that adds the movies from a list to a JsonNode
     *
     * @param node        - the node where the output will be written
     * @param movies      - the list of movies
     * @param currentUser - the current user
     */
    public static void addMovieListtoNode(final ObjectNode node, final ArrayList<Movies> movies,
                                          final Users currentUser) {
        ObjectMapper objectMapper = new ObjectMapper();
        node.put("error", (JsonNode) null);
        ArrayNode currentList = objectMapper.createArrayNode();
        for (Movies movie : movies) {
            if (!movie.getCountriesBanned().contains(currentUser.getCredetials().getCountry())) {
                ObjectNode movieDetails = objectMapper.createObjectNode();
                addMovieToNode(movieDetails, movie);
                currentList.add(movieDetails);
            }
        }
        node.put("currentMoviesList", currentList);
    }

    /**
     * Method that adds the movies from a list to a JsonNode
     *
     * @param list        - the ArrayNode where the movies will be added
     * @param movies      - the list of movies
     * @param currentUser - the current user
     */
    public static void addFeaturedListToList(final ArrayNode list, final ArrayList<Movies> movies,
                                             final Users currentUser) {
        ObjectMapper objectMapper = new ObjectMapper();
        for (Movies movie : movies) {
            if (!movie.getCountriesBanned().contains(currentUser.getCredetials().getCountry())) {
                ObjectNode movieDetails = objectMapper.createObjectNode();
                addMovieToNode(movieDetails, movie);
                list.add(movieDetails);
            }
        }
    }

    /**
     * Method that add the credentials and data of the user to a JsonNode
     *
     * @param node        - the node where the output will be written
     * @param currentUser - the current user
     */
    public static void addCurrentUserToNode(final ObjectNode node, final Users currentUser) {
        ObjectMapper objectMapper = new ObjectMapper();
        ObjectNode userNode = objectMapper.createObjectNode();
        ObjectNode creds = objectMapper.createObjectNode();
        addCredentialsToNode(creds, currentUser.getCredetials());
        userNode.put("credentials", creds);
        addUserData(userNode, currentUser);
        node.put("currentUser", userNode);
    }

}
