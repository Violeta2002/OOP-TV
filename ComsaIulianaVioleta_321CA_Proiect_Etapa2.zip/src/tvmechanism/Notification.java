package tvmechanism;

// Class that implements the notification mechanism that contains details about the notification
public final class Notification {
    private String movieName;
    private String message;

    public Notification() {
    }

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(final String movieName) {
        this.movieName = movieName;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(final String message) {
        this.message = message;
    }
}
