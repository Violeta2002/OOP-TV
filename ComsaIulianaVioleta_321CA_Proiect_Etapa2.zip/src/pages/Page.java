package pages;

// Base class for all pages
abstract class Page {
    abstract int canVisit(String pageNname);
}
