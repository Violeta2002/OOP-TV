package command;

interface Command {
    int execute();
}
